package com.example.swift;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.prowidesoftware.swift.model.mx.AbstractMX;

public class SwiftBatchProcessor {

    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage: java -jar swift-batch-processor-1.0-SNAPSHOT.jar <input-file.csv>");
            System.exit(1);
        }

        String inputFilePath = args[0];
        try {
            Path path = Paths.get(inputFilePath);
            if (!Files.exists(path)) {
                System.err.println("Error: File not found at " + inputFilePath);
                System.exit(1);
            }

            System.out.println("Reading and parsing CSV file: " + inputFilePath);
            
            ObjectMapper mapper = new ObjectMapper();
            List<ObjectNode> jsonList = new ArrayList<>();
            
            // Regex patterns to identify messages within CSV fields
            Pattern mt103Pattern = Pattern.compile("\\{1:[\\s\\S]*?-\\}");
            Pattern pacsPattern = Pattern.compile("<(?:[a-zA-Z0-9]+:)?Document[\\s\\S]*?</(?:[a-zA-Z0-9]+:)?Document>");

            try (Reader in = new FileReader(inputFilePath)) {
                // Use EXCEL format as it handles quotes and newlines well (standard CSV)
                Iterable<CSVRecord> records = CSVFormat.EXCEL.parse(in);
                for (CSVRecord record : records) {
                    for (String field : record) {
                        if (field == null) continue;
                        
                        Matcher mt103Matcher = mt103Pattern.matcher(field);
                        while (mt103Matcher.find()) {
                            jsonList.add(processMT103(mt103Matcher.group(), mapper));
                        }
                        
                        Matcher pacsMatcher = pacsPattern.matcher(field);
                        while (pacsMatcher.find()) {
                            jsonList.add(processPacs008(pacsMatcher.group(), mapper));
                        }
                    }
                }
            }
            
            String jsonOutput = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonList);
            
            // Determine output filename (replace extension with .json)
            String outputFilePath = inputFilePath;
            int dotIndex = outputFilePath.lastIndexOf('.');
            if (dotIndex > 0) {
                outputFilePath = outputFilePath.substring(0, dotIndex) + ".json";
            } else {
                outputFilePath += ".json";
            }
            
            Files.write(Paths.get(outputFilePath), jsonOutput.getBytes());
            System.out.println("Successfully processed file.");
            System.out.println("Extracted " + jsonList.size() + " messages.");
            System.out.println("Output saved to: " + outputFilePath);
            
        } catch (Exception e) {
            System.err.println("Error processing file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static ObjectNode processMT103(String msg, ObjectMapper mapper) {
        ObjectNode node = mapper.createObjectNode();
        node.put("transaction_id", UUID.randomUUID().toString());
        node.put("type", "MT103");
        node.put("Payload", msg.trim());
        return node;
    }

    private static ObjectNode processPacs008(String msg, ObjectMapper mapper) {
        ObjectNode node = mapper.createObjectNode();
        node.put("transaction_id", UUID.randomUUID().toString());
        node.put("type", "pacs.008");
        
        try {
            // Parse using Prowide ISO 20022 library
            AbstractMX mx = AbstractMX.parse(msg);
            
            if (mx != null) {
                // Store the parsed XML string (or serialize the MX object)
                node.put("Payload", mx.message());
            } else {
                node.put("Payload", msg.trim());
            }
        } catch (Exception e) {
            System.err.println("Failed to parse MX message: " + e.getMessage());
            node.put("Payload", msg.trim());
        }
        
        return node;
    }
}
