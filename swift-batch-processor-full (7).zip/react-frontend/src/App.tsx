import React, { useState } from 'react';
import { FileJson, Code2, Copy, CheckCircle2, ArrowRight, FileText, Download, Upload, FileCode } from 'lucide-react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import pomXml from './java/pom.xml?raw';
import packageJson from '../package.json?raw';
import viteConfig from '../vite.config.ts?raw';
import tsconfig from '../tsconfig.json?raw';
import indexHtml from '../index.html?raw';
import mainTsx from './main.tsx?raw';
import indexCss from './index.css?raw';
import appTsx from './App.tsx?raw';
import typesDts from './types.d.ts?raw';
import javaCode from './java/SwiftBatchProcessor.java?raw';

const samplePacs008 = `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08">
    <FIToFICstmrCdtTrf>
        <GrpHdr>
            <MsgId>MSGID123456789</MsgId>
            <CreDtTm>2023-10-25T14:30:00Z</CreDtTm>
            <NbOfTxs>1</NbOfTxs>
            <SttlmInf>
                <SttlmMtd>CLRG</SttlmMtd>
            </SttlmInf>
        </GrpHdr>
        <CdtTrfTxInf>
            <PmtId>
                <InstrId>INSTRID987654321</InstrId>
                <EndToEndId>E2EID123456789</EndToEndId>
                <TxId>TXID123456789</TxId>
            </PmtId>
            <IntrBkSttlmAmt Ccy="USD">1000.00</IntrBkSttlmAmt>
            <IntrBkSttlmDt>2023-10-26</IntrBkSttlmDt>
            <ChrgBr>SHAR</ChrgBr>
            <Dbtr>
                <Nm>John Doe</Nm>
                <PstlAdr>
                    <Ctry>US</Ctry>
                </PstlAdr>
            </Dbtr>
            <DbtrAcct>
                <Id>
                    <IBAN>US12345678901234567890</IBAN>
                </Id>
            </DbtrAcct>
            <DbtrAgt>
                <FinInstnId>
                    <BICFI>BOFAUS3N</BICFI>
                </FinInstnId>
            </DbtrAgt>
            <CdtrAgt>
                <FinInstnId>
                    <BICFI>CHASUS33</BICFI>
                </FinInstnId>
            </CdtrAgt>
            <Cdtr>
                <Nm>Jane Smith</Nm>
                <PstlAdr>
                    <Ctry>US</Ctry>
                </PstlAdr>
            </Cdtr>
            <CdtrAcct>
                <Id>
                    <IBAN>US09876543210987654321</IBAN>
                </Id>
            </CdtrAcct>
        </CdtTrfTxInf>
    </FIToFICstmrCdtTrf>
</Document>`;

export default function App() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [activeTab, setActiveTab] = useState<'processor' | 'java'>('processor');
  const [copied, setCopied] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setInput(content);
    };
    reader.readAsText(file);
    
    // Reset input so the same file can be uploaded again if needed
    e.target.value = '';
  };

  const loadSample = () => {
    setInput(samplePacs008);
  };

  const handleProcess = () => {
    // Regex for MT103
    const mt103Regex = /\{1:[\s\S]*?-\}/g;
    // Regex for pacs.008
    const pacsRegex = /<(?:[a-zA-Z0-9]+:)?Document[\s\S]*?<\/(?:[a-zA-Z0-9]+:)?Document>/g;
    
    const messages: string[] = [];
    
    let match;
    while ((match = mt103Regex.exec(input)) !== null) {
      messages.push(match[0]);
    }
    
    while ((match = pacsRegex.exec(input)) !== null) {
      messages.push(match[0]);
    }
    
    const result = messages.map(msg => ({
      transaction_id: crypto.randomUUID(),
      Payload: msg.trim()
    }));
    
    setOutput(JSON.stringify(result, null, 2));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJson = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'application/json' });
    saveAs(blob, 'processed-swift.json');
  };

  const downloadProject = async () => {
    const zip = new JSZip();
    
    // --- Java Backend ---
    const javaFolder = zip.folder("java-backend");
    if (javaFolder) {
      javaFolder.file("pom.xml", pomXml);
      javaFolder.folder("src/main/java/com/example/swift")?.file("SwiftBatchProcessor.java", javaCode);
    }
    
    // --- React Frontend ---
    const reactFolder = zip.folder("react-frontend");
    if (reactFolder) {
      reactFolder.file("package.json", packageJson);
      reactFolder.file("vite.config.ts", viteConfig);
      reactFolder.file("tsconfig.json", tsconfig);
      reactFolder.file("index.html", indexHtml);
      
      const srcFolder = reactFolder.folder("src");
      if (srcFolder) {
        srcFolder.file("main.tsx", mainTsx);
        srcFolder.file("index.css", indexCss);
        srcFolder.file("App.tsx", appTsx);
        srcFolder.file("types.d.ts", typesDts);
        
        const srcJavaFolder = srcFolder.folder("java");
        if (srcJavaFolder) {
          srcJavaFolder.file("SwiftBatchProcessor.java", javaCode);
          srcJavaFolder.file("pom.xml", pomXml);
        }
      }
    }
    
    // Generate ZIP and download
    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, "swift-batch-processor-full.zip");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <FileJson className="w-6 h-6 text-indigo-600" />
          <h1 className="text-xl font-semibold text-slate-800">SWIFT Batch Processor</h1>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('processor')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${activeTab === 'processor' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Web Processor
          </button>
          <button
            onClick={() => setActiveTab('java')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${activeTab === 'java' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Java Project
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        {activeTab === 'processor' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium flex items-center gap-2">
                  <FileText className="w-5 h-5 text-slate-500" />
                  Input Batch Data
                </h2>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-500 bg-slate-200 px-2 py-1 rounded font-medium">MT103 / pacs.008</span>
                  <button
                    onClick={loadSample}
                    className="flex items-center gap-1 text-sm bg-white border border-slate-300 text-slate-700 px-3 py-1.5 rounded-md hover:bg-slate-50 transition-colors shadow-sm"
                  >
                    <FileCode className="w-4 h-4" />
                    Load Sample
                  </button>
                  <input
                    type="file"
                    accept=".csv,.txt,.xml"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="csv-upload"
                  />
                  <label
                    htmlFor="csv-upload"
                    className="cursor-pointer flex items-center gap-1 text-sm bg-white border border-slate-300 text-slate-700 px-3 py-1.5 rounded-md hover:bg-slate-50 transition-colors shadow-sm"
                  >
                    <Upload className="w-4 h-4" />
                    Upload File
                  </label>
                </div>
              </div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your SWIFT MT103 or pacs.008 batch messages here...&#10;&#10;Example MT103:&#10;{1:F01BANKDEFMAXXX2039063581}{2:O1031609050901BANKDEFXAXXX89549812080509011609N}{4:&#10;:20:0061350113089908&#10;:23B:CRED&#10;:32A:050902JPY10000000,&#10;:33B:JPY10000000,&#10;:50K:/12345678&#10;COMPANY A&#10;:59:/87654321&#10;COMPANY B&#10;:71A:SHA&#10;-}"
                className="w-full h-[600px] p-4 rounded-xl border border-slate-200 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all font-mono text-sm resize-none"
              />
              <button
                onClick={handleProcess}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors shadow-sm"
              >
                Process Messages
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium flex items-center gap-2">
                  <FileJson className="w-5 h-5 text-slate-500" />
                  JSON Output
                </h2>
                <div className="flex items-center gap-3">
                  <button
                    onClick={downloadJson}
                    disabled={!output}
                    className="text-sm flex items-center gap-1 text-slate-600 hover:text-indigo-600 disabled:opacity-50 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    Download JSON
                  </button>
                  <button
                    onClick={() => copyToClipboard(output)}
                    disabled={!output}
                    className="text-sm flex items-center gap-1 text-slate-600 hover:text-indigo-600 disabled:opacity-50 transition-colors"
                  >
                    {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                    {copied ? 'Copied!' : 'Copy JSON'}
                  </button>
                </div>
              </div>
              <textarea
                value={output}
                readOnly
                placeholder="Processed JSON will appear here..."
                className="w-full h-[600px] p-4 rounded-xl border border-slate-200 bg-slate-50 shadow-sm font-mono text-sm resize-none text-slate-700"
              />
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto flex flex-col gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-slate-800 mb-2">Full Project Download</h2>
                <p className="text-slate-600">
                  Download a complete ZIP containing both the simple Java CLI backend and this React frontend web application.
                </p>
              </div>
              <button
                onClick={downloadProject}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg font-medium flex items-center gap-2 transition-colors shadow-sm whitespace-nowrap"
              >
                <Download className="w-5 h-5" />
                Download Full .zip
              </button>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="bg-slate-800 px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-200">
                  <Code2 className="w-5 h-5" />
                  <span className="font-mono text-sm">src/main/java/com/example/swift/SwiftBatchProcessor.java</span>
                </div>
                <button
                  onClick={() => copyToClipboard(javaCode)}
                  className="text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-sm"
                >
                  {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy Code'}
                </button>
              </div>
              <div className="p-6 overflow-x-auto bg-slate-900">
                <pre className="font-mono text-sm text-slate-300">
                  <code>{javaCode}</code>
                </pre>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="bg-slate-800 px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-200">
                  <Code2 className="w-5 h-5" />
                  <span className="font-mono text-sm">pom.xml</span>
                </div>
              </div>
              <div className="p-6 overflow-x-auto bg-slate-900">
                <pre className="font-mono text-sm text-slate-300">
                  <code>{pomXml}</code>
                </pre>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
